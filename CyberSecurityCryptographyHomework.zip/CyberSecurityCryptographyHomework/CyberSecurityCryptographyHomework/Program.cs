﻿using Org.BouncyCastle.Pqc.Crypto.Crystals.Kyber;
using Org.BouncyCastle.Security;
using Spectre.Console;


Console.WriteLine("***************** KYBER ENCRYPTION *******************");

var random = new SecureRandom();
var keyGenParameters = new KyberKeyGenerationParameters(random, KyberParameters.kyber768);

var kyberKeyPairGenerator = new KyberKeyPairGenerator();
kyberKeyPairGenerator.Init(keyGenParameters);

// generate key pair for Alice
var aliceKeyPair = kyberKeyPairGenerator.GenerateKeyPair();

// get and view the keys
var alicePublic = (KyberPublicKeyParameters)aliceKeyPair.Public;
var alicePrivate = (KyberPrivateKeyParameters)aliceKeyPair.Private;
var pubEncoded = alicePublic.GetEncoded();
var privateEncoded = alicePrivate.GetEncoded();
PrintPanel("Alice's keys", new[] { $":unlocked: Public: {pubEncoded.PrettyPrint()}", $":locked: Private: {privateEncoded.PrettyPrint()}" });

// Bob encapsulates a new shared secret using Alice's public key
var bobKyberKemGenerator = new KyberKemGenerator(random);
var encapsulatedSecret = bobKyberKemGenerator.GenerateEncapsulated(alicePublic);
var bobSecret = encapsulatedSecret.GetSecret();

// cipher text produced by Bob and sent to Alice
var cipherText = encapsulatedSecret.GetEncapsulation();

// Alice decapsulates a new shared secret using Alice's private key
var aliceKemExtractor = new KyberKemExtractor(alicePrivate);
var aliceSecret = aliceKemExtractor.ExtractSecret(cipherText);
PrintPanel("Key encapsulation", new[] { $":man: Bob's secret: {bobSecret.PrettyPrint()}", $":locked_with_key: Cipher text (Bob -> Alice): {cipherText.PrettyPrint()}", $":woman: Alice's secret: {aliceSecret.PrettyPrint()}" });

// Compare secrets
var equal = bobSecret.SequenceEqual(aliceSecret);
PrintPanel("Verification", new[] { $"{(equal ? ":check_mark_button:" : ":cross_mark:")} Secrets equal!" });


static void PrintPanel(string header, string[] data)
{
    var content = string.Join(Environment.NewLine, data);
    var panel = new Panel(content)
    {
        Header = new PanelHeader(header)
    };
    AnsiConsole.Write(panel);
}

public static class FormatExtensions
{
    public static string PrettyPrint(this byte[] bytes)
    {
        var base64 = Convert.ToBase64String(bytes);
        return base64.Length > 50 ? $"{base64[..25]}...{base64[^25..]}" : base64;
    }
}